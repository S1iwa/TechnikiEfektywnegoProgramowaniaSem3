//
// Created by S1iwa on 12.10.2025.
//

#ifndef TECHNIKIEFEKTYWNEGOPROGRAMOWANIASEM3_MAIN_H
#define TECHNIKIEFEKTYWNEGOPROGRAMOWANIASEM3_MAIN_H

const int value = 34;

void wyswietlElementyTablicy(int* table, int iSize);
void v_alloc_table_fill_34(int iSize);

#endif //TECHNIKIEFEKTYWNEGOPROGRAMOWANIASEM3_MAIN_H