//
// Created by S1iwa on 12.10.2025.
//

#ifndef TECHNIKIEFEKTYWNEGOPROGRAMOWANIASEM3_MAIN_H
#define TECHNIKIEFEKTYWNEGOPROGRAMOWANIASEM3_MAIN_H
#include "CTable.h"

void v_mod_tab(CTable *pcTab, int iNewSize);
void v_mod_tab(CTable cTab, int iNewSize);

#endif //TECHNIKIEFEKTYWNEGOPROGRAMOWANIASEM3_MAIN_H