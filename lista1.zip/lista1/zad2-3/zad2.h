//
// Created by S1iwa on 12.10.2025.
//

#ifndef TECHNIKIEFEKTYWNEGOPROGRAMOWANIASEM3_MAIN_H
#define TECHNIKIEFEKTYWNEGOPROGRAMOWANIASEM3_MAIN_H

void wyswietlElementyTablicy(int **table, int iSizeX, int iSizeY);
bool b_alloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY);
bool b_dealoc_table_2_dim(int ***piTable, int iSizeY);

#endif //TECHNIKIEFEKTYWNEGOPROGRAMOWANIASEM3_MAIN_H