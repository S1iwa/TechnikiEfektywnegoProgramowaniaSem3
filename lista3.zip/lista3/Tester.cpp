//
// Created by micha on 23.11.2025.
//

#include "Interface.h"

int main() {
  // UŁAAAA ale dużo
  Interface interface;
  interface.run();
  return 0;
}