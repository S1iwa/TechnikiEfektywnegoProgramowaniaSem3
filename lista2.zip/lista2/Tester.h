//
// Created by S1iwa on 10/26/2025.
//

#ifndef TEPSEM3_TESTER_H
#define TEPSEM3_TESTER_H

class Tester {};

#endif  // TEPSEM3_TESTER_H
